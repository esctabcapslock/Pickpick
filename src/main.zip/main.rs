// use servertime::Servertime;
// use std::net::{Ipv4Addr,SocketAddr, SocketAddrV4, IpAddr};
// use std::time::{Instant};

use iced::{
    alignment, button, scrollable, slider, text_input, Button, Checkbox, Color,
    Column, Container, ContentFit, Element, Length, Radio, Row, Sandbox,
    Scrollable, Settings, Slider, Space, Text, TextInput, Toggler,
};
// fn main() {
pub fn main() -> iced::Result{
    let mut setting = Settings::default();

    setting.window.size = (200,200);
    setting.window.always_on_top = true;
     Counter::run(setting)
    
    // servertime::get(&SocketAddr::V4(SocketAddrV4::new(Ipv4Addr::new(52,78,231,108), 80)), "github.com").unwrap();
    // servertime::get(&SocketAddr::V4(SocketAddrV4::new(Ipv4Addr::new(223,130,195,200), 80)), "www.naver.com").unwrap();
    // servertime::get(&SocketAddr::V4(SocketAddrV4::new(Ipv4Addr::new(142,250,196,132), 80)), "www.google.com").unwrap();
    // let start = Instant::now();
    // loop{
    // let t =  Servertime::new(&SocketAddr::V4(SocketAddrV4::new(Ipv4Addr::new(127,0,0,1), 80)), "localhost").gettime().unwrap();
    // println!("Hello, world!");
    // let duration = start.elapsed();
    // println!("Time elapsed in expensive_function() is: {:?}", duration);
    // println!("ans: {:?}",t);
    // t.get_offset_range();
    // }/

    // use servertime::dns::DNS;
    // let u = IpAddr::V4(Ipv4Addr::new(1,1,1,1));
    // let d = DNS::new(&u);
    // let k = d.get(&String::from("github.com"));
    // println!("{:?}",k);
    // d.get(&String::from("www.naver.com"));

    
    // Clock::run(Settings::default())
    
}

struct Counter {
    // The counter value
    value: i32,

    // The local state of the two buttons
    scroll: scrollable::State,
    increment_button: button::State,
    decrement_button: button::State,
    text_input: text_input::State,
}

#[derive(Debug, Clone)]
pub enum Message {
    IncrementPressed,
    DecrementPressed,
    StepMessage(StepMessage),
}

impl Sandbox for Counter {
    type Message = Message;
    fn new() -> Counter{
        Counter{
            value:0,
            scroll:scrollable::State::new(),
            increment_button:button::State::new(),
            decrement_button:button::State::new(),
            text_input:text_input::State::new(),
        }
    }
     fn view(&mut self) -> Element<Message> {

        // let Counter {
        //     value,
        //     scroll,
        //     increment_button,
        //     decrement_button,
        //     text_input,
        //     ..
        // } = self;

        let mut controls = Row::new();
        // We use a column: a simple vertical layout

        
        let text_input = TextInput::new(
            &mut self.text_input,
            "Type something to continue...",
            "value",
            StepMessage::InputChanged,
        ).padding(10)
        .size(30);

        let bt1 = Button::new(&mut self.increment_button, Text::new("+"))
        .on_press(Message::IncrementPressed);
        let txt = Text::new(self.value.to_string()).size(50);
        let bt2 = Button::new(&mut self.decrement_button, Text::new("-"))
        .on_press(Message::DecrementPressed);
    

        controls.push(txt);
        // controls.push(text_input);

        // let content = Column::new()
        // .spacing(20).push(Text::new("text_input").size(50)).push(text_input);
            // .push(
            //     bt1,
            // )
            // .push(
            //     txt
            // )
            // .push(
            //     bt2
            // ).push(text_input);
            
            // let content = Column::new().spacing(20).push(Text::new("text_input").size(50)).push(text_input);

        let content: Element<_> = Column::new()
        .max_width(540)
        .spacing(20)
        .padding(20)
        .push(controls)
        .into();

        // let mut scroll = scrollable::State::new();
        let scrollable = Scrollable::new(&mut self.scroll)
            .push(Container::new(content).width(Length::Fill).center_x());


        Container::new(scrollable)
            .height(Length::Fill)
            .center_y()
            .into()
    }

    

     fn update(&mut self, message: Message) {
        match message {
            Message::IncrementPressed => {
                self.value += 1;
            }
            Message::DecrementPressed => {
                self.value -= 1;
            }
            Message::StepMessage(i)=>{
                
            }
        }
    }

    
    fn title(&self) -> String{
        String::from("")
    }

    fn background_color(&self) -> Color {
        Color::WHITE
    }

    fn scale_factor(&self) -> f64 {
        1.0
    }

    fn should_exit(&self) -> bool {
        false
    }

    fn run(settings: Settings<()>) -> Result<(), iced::Error>
    where
        Self: 'static + Sized,
    {
        <Self as iced::Application>::run(settings)
    }

}


#[derive(Debug, Clone)]
pub enum StepMessage {
    InputChanged(String),
}